import React from 'react';
import { Github, Linkedin, Mail, BookOpen, Code, Globe } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      {/* Hero Section */}
      <div className="max-w-4xl mx-auto px-4 py-20 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            Prajwal Weladi
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Software Developer & Technology Enthusiast
          </p>
          <div className="flex justify-center space-x-4">
            <a href="#" className="hover:text-blue-400 transition-colors">
              <Github className="h-6 w-6" />
            </a>
            <a href="#" className="hover:text-blue-400 transition-colors">
              <Linkedin className="h-6 w-6" />
            </a>
            <a href="mailto:contact@example.com" className="hover:text-blue-400 transition-colors">
              <Mail className="h-6 w-6" />
            </a>
          </div>
        </div>

        {/* About Section */}
        <div className="mt-20">
          <h2 className="text-2xl font-semibold mb-6 flex items-center justify-center">
            <BookOpen className="h-6 w-6 mr-2" />
            About Me
          </h2>
          <div className="bg-slate-800/50 rounded-lg p-6 backdrop-blur-sm">
            <p className="text-gray-300 leading-relaxed">
              Hello! I'm Prajwal, a passionate software developer with a keen interest in building
              modern web applications. I love exploring new technologies and creating solutions
              that make a difference. When I'm not coding, you can find me reading tech blogs
              or contributing to open-source projects.
            </p>
          </div>
        </div>

        {/* Skills Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-semibold mb-6 flex items-center justify-center">
            <Code className="h-6 w-6 mr-2" />
            Skills
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              "JavaScript/TypeScript",
              "React.js",
              "Node.js",
              "Python",
              "SQL",
              "Git"
            ].map((skill, index) => (
              <div
                key={index}
                className="bg-slate-800/50 p-4 rounded-lg text-center hover:bg-slate-700/50 transition-colors"
              >
                {skill}
              </div>
            ))}
          </div>
        </div>

        {/* Projects Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-semibold mb-6 flex items-center justify-center">
            <Globe className="h-6 w-6 mr-2" />
            Featured Projects
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-800/50 rounded-lg p-6 hover:bg-slate-700/50 transition-colors">
              <h3 className="text-xl font-semibold mb-2">Project One</h3>
              <p className="text-gray-300">
                A web application built with React and Node.js that helps users manage their daily tasks.
              </p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-6 hover:bg-slate-700/50 transition-colors">
              <h3 className="text-xl font-semibold mb-2">Project Two</h3>
              <p className="text-gray-300">
                An e-commerce platform developed using modern web technologies and best practices.
              </p>
            </div>
          </div>
        </div>

        {/* Contact Section */}
        <div className="mt-16 text-center">
          <p className="text-gray-300">
            Interested in working together? Let's connect!
          </p>
          <button className="mt-4 bg-blue-500 hover:bg-blue-600 px-6 py-2 rounded-full transition-colors">
            Get in Touch
          </button>
        </div>
      </div>

      {/* Footer */}
      <footer className="text-center py-6 text-gray-400">
        <p>© 2024 Prajwal Weladi. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;